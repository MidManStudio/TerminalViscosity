// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/client.md, section "loadout.odin"
// ============================================================================

package carry

import "../chemistry"
import "../lab"

LOADOUT_SLOTS :: lab.LOADOUT_SLOTS // how many balloons a loadout holds. It is not decided, so it is set in one place, the lab.

// A tied balloon: what is in it, and the drawing on it. It is the data a balloon
// needs to be sent to the server and shown to the other players. A balloon carries the
// whole mixture of the vessel it was filled from, with its temperature in degrees.
Item :: struct {
	used: bool,
	mix:  chemistry.Mixture,
	art:  u16, // the id of its drawing in the art store, 0 while it has none
}

// What the server needs of a balloon in the loadout: the whole mixture and the drawing.
// `compound` and `volume_ml` are the compound there is most of and the total, which is
// all the wire carries until it carries a mixture.
Preset :: struct {
	mix:       chemistry.Mixture,
	compound:  u16,
	volume_ml: u16,
	art:       u16,
}

// The place the crosshair is on that a balloon can be put or taken.
Spot :: enum u8 {
	None,
	Fill, // the clamp of the fill station
	Paint, // the clamp of the paint station
	Tablet, // the tablet beside it
	Slot, // a hook of the loadout rack
	Burn, // the incinerator
}

// The one action the grab button does at a spot, with a balloon or without.
Balloon_Action :: enum u8 {
	None,
	Tie_Take, // tie off the balloon at the fill station and take it
	Clamp, // clamp the balloon in the hand into the paint station
	Take_Paint, // take the balloon out of the paint station
	Paint, // draw on the tablet, which the balloon in the clamp wears
	Store, // hang the balloon in the hand on a hook
	Take_Slot, // take the balloon off a hook
	Burn, // burn the balloon in the hand in the incinerator, which is gone for good
}

// The balloons the player has: one in the hand, one in the paint station, and the
// hooks of the loadout, which is what is kept between matches.
Loadout :: struct {
	hand:      Item,
	paint:     Item, // in the clamp of the paint station, wearing what is drawn on the tablet
	slots:     [LOADOUT_SLOTS]Item,
	spot:      Spot,
	spot_slot: int, // which hook, when the spot is a slot
	spot_t:    f32,
}

// Whether a balloon is in the hands. The hands hold a balloon or a vessel, not both.
loadout_hands_full :: proc(lo: ^Loadout) -> bool {
	return lo.hand.used
}

// Finds what the crosshair is on among the fill clamp, the paint station, the tablet,
// the hooks of the rack, and the incinerator: the nearest one within reach, and nearer than any vessel. Run it
// after `filler_aim`, which says whether the crosshair is on the fill clamp.
loadout_aim :: proc(lo: ^Loadout, f: ^Filler, props: ^Props, v: View) {
	dir := -v.back
	best_t := f32(1e9)
	lo.spot, lo.spot_slot = .None, -1
	if f.aimed {
		best_t = f.aimed_t
		lo.spot = .Fill
	}
	if t, hit := ray_box(v.eye, dir, lab.PAINT_AIM_LOW, lab.PAINT_AIM_HIGH); hit && t < best_t {
		best_t = t
		lo.spot = .Paint
	}
	if t, hit := ray_box(v.eye, dir, lab.TABLET_AIM_LOW, lab.TABLET_AIM_HIGH); hit && t < best_t {
		best_t = t
		lo.spot = .Tablet
	}
	for i in 0 ..< LOADOUT_SLOTS {
		low, high := lab.slot_aim(i)
		if t, hit := ray_box(v.eye, dir, low, high); hit && t < best_t {
			best_t = t
			lo.spot, lo.spot_slot = .Slot, i
		}
	}
	if t, hit := ray_box(v.eye, dir, lab.INCINERATOR_AIM_LOW, lab.INCINERATOR_AIM_HIGH); hit && t < best_t {
		best_t = t
		lo.spot, lo.spot_slot = .Burn, -1
	}
	lo.spot_t = best_t
	if lo.spot == .None || best_t > REACH || (props.aimed != -1 && best_t >= props.aimed_t) {
		lo.spot, lo.spot_slot = .None, -1
	}
}

// What the grab button would do now. Nothing while a vessel is held. At the fill
// clamp it ties off a balloon that has something in it, and takes it, with empty
// hands. At the paint station and a hook it puts the balloon in the hand there if the
// place is free, and takes the balloon there if the hand is free. At the tablet it
// starts drawing, if a balloon is clamped, in hands that hold no vessel. At the incinerator
// it burns the balloon in the hand, and with empty hands it does nothing.
balloon_action :: proc(lo: ^Loadout, f: ^Filler, props: ^Props) -> Balloon_Action {
	if props.held != -1 {
		return .None
	}
	switch lo.spot {
	case .None:
	case .Fill:
		if !lo.hand.used && f.present && ml_of(&f.mix) > 0 {
			return .Tie_Take
		}
	case .Paint:
		if lo.hand.used && !lo.paint.used {
			return .Clamp
		} else if !lo.hand.used && lo.paint.used {
			return .Take_Paint
		}
	case .Tablet:
		if lo.paint.used {
			return .Paint
		}
	case .Slot:
		slot := lo.slots[lo.spot_slot]
		if lo.hand.used && !slot.used {
			return .Store
		} else if !lo.hand.used && slot.used {
			return .Take_Slot
		}
	case .Burn:
		if lo.hand.used {
			return .Burn
		}
	}
	return .None
}

// Ties off the balloon at the fill station and takes what is in it, up to a full
// balloon: a stretched balloon is let down to full, and the excess is lost. The
// station clamps a fresh balloon after a short wait.
filler_tie :: proc(f: ^Filler) -> (item: Item, let_out: f32) {
	have := ml_of(&f.mix)
	if !f.present || have <= 0 {
		return {}, 0
	}
	item = {
		used = true,
		mix  = f.mix,
	}
	if have > BALLOON_REST_ML {
		chemistry.mix_scale(&item.mix, BALLOON_REST_ML / have)
	}
	let_out = have - ml_of(&item.mix)
	f.present = false
	f.mix = {}
	f.respawn = FILLER_RESPAWN
	return
}

// Does the action. Returns what was let out of a stretched balloon when it was tied,
// and false if the action cannot be done.
balloon_do :: proc(lo: ^Loadout, f: ^Filler, action: Balloon_Action) -> (let_out: f32, ok: bool) {
	switch action {
	case .None:
		return 0, false
	case .Paint:
		return 0, lo.paint.used // nothing moves: the scene starts the drawing
	case .Tie_Take:
		item, out := filler_tie(f)
		if !item.used {
			return 0, false
		}
		lo.hand = item
		return out, true
	case .Clamp:
		lo.paint, lo.hand = lo.hand, {}
	case .Take_Paint:
		lo.hand, lo.paint = lo.paint, {}
	case .Store:
		lo.slots[lo.spot_slot], lo.hand = lo.hand, {}
	case .Take_Slot:
		lo.hand, lo.slots[lo.spot_slot] = lo.slots[lo.spot_slot], {}
	case .Burn:
		if !lo.hand.used {
			return 0, false
		}
		lo.hand = {} // only the hand: whatever is in the paint station or on a hook stays
	}
	return 0, true
}

// How many hooks hold a balloon.
loadout_count :: proc(lo: ^Loadout) -> int {
	n := 0
	for s in lo.slots {
		if s.used {
			n += 1
		}
	}
	return n
}

// What the server needs of each balloon in the loadout, hook by hook, as the
// recipe and the drawing of each. Empty hooks are left out, and `count` says how many.
loadout_presets :: proc(lo: ^Loadout) -> (out: [LOADOUT_SLOTS]Preset, count: int) {
	for &s in lo.slots {
		if !s.used {
			continue
		}
		out[count] = {
			mix       = s.mix,
			compound  = main_of(&s.mix),
			volume_ml = u16(clamp(ml_of(&s.mix) + 0.5, 0, f32(BALLOON_REST_ML))),
			art       = s.art,
		}
		count += 1
	}
	return
}
