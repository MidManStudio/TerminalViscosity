// ============================================================================
// NOTICE: Full documentation, design decisions, and fix history for this file
// live in docs/client.md, section "interact_ui.odin"
// ============================================================================

package main

import rl "vendor:raylib"
import "carry"
import "core:strconv"

// One rounded box of a hand icon, in a unit square with y pointing down.
// `shade` darkens the box so a thumb can be told apart from the fist.
Icon_Box :: struct {
	x, y, w, h: f32,
	shade:      f32,
}

ICON_OPEN :: [?]Icon_Box {
	{0.22, 0.50, 0.56, 0.42, 1}, // palm
	{0.22, 0.14, 0.115, 0.42, 1}, // index
	{0.345, 0.06, 0.115, 0.50, 1}, // middle
	{0.47, 0.12, 0.115, 0.46, 1}, // ring
	{0.595, 0.24, 0.115, 0.34, 1}, // little
	{0.04, 0.54, 0.26, 0.13, 1}, // thumb, out to the side
}

ICON_CLOSED :: [?]Icon_Box {
	{0.20, 0.32, 0.60, 0.52, 1}, // fist
	{0.20, 0.20, 0.14, 0.24, 1}, // knuckles
	{0.355, 0.17, 0.14, 0.27, 1},
	{0.51, 0.19, 0.14, 0.25, 1},
	{0.66, 0.24, 0.14, 0.20, 1},
	{0.26, 0.60, 0.40, 0.15, 0.78}, // thumb across the front
}

// The grab button, in the bottom right corner. A finger that lands on it does
// not move or look.
grab_button :: proc(w, h: f32) -> [4]f32 {
	size := max(f32(64), h * 0.13)
	return {w - size * 1.8 - 24, h - size - 24, size * 1.8, size}
}

// The jump button, just above the grab button and as wide as it.
jump_button :: proc(w, h: f32) -> [4]f32 {
	g := grab_button(w, h)
	height := g.w * 0.8
	return {g.x, g.y - height - 16, g.z, height}
}

// The button that opens the liquid sim test, just under the scene switch.
bench_button :: proc(w, h: f32) -> [4]f32 {
	b := switch_button(w, h)
	return {b.x, b.y + b.w + 12, b.z, b.w}
}

// A button on a dark backing with a bright edge and a shadowed label, so it
// reads on the light walls and floor as well as on the dark counters.
draw_button :: proc(b: [4]f32, label: cstring, fill, edge, ink: rl.Color) {
	rect := rl.Rectangle{b.x, b.y, b.z, b.w}
	rl.DrawRectangleRounded(rect, 0.3, 8, fill)
	rl.DrawRectangleRoundedLinesEx(rect, 0.3, 8, 3, edge)
	font := i32(min(b.z / 5, b.w * 0.34))
	x := i32(b.x + b.z * 0.5) - rl.MeasureText(label, font) / 2
	y := i32(b.y + b.w * 0.5) - font / 2
	rl.DrawText(label, x + 1, y + 2, font, {0, 0, 0, 220})
	rl.DrawText(label, x, y, font, ink)
}

// The button says "grab" until something is held, and then "release". It is
// dimmer when there is nothing within reach to grab.
draw_grab_button :: proc(w, h: f32, state: carry.State) {
	label: cstring = "grab"
	fill := rl.Color{10, 18, 28, 150}
	edge := rl.Color{200, 210, 222, 120}
	ink := rl.Color{200, 210, 222, 170}
	switch state {
	case .Idle:
	case .Reaching:
		fill, edge, ink = {10, 44, 50, 215}, {60, 230, 215, 255}, rl.RAYWHITE
	case .Holding:
		label = "release"
		fill, edge, ink = {14, 74, 74, 230}, {60, 230, 215, 255}, rl.RAYWHITE
	}
	draw_button(grab_button(w, h), label, fill, edge, ink)
}

// The jump button is dimmer while the player is already in the air.
draw_jump_button :: proc(w, h: f32, airborne: bool) {
	fill := rl.Color{10, 18, 28, 190}
	edge := rl.Color{230, 236, 242, 220}
	ink := rl.RAYWHITE
	if airborne {
		fill, edge, ink = {10, 18, 28, 120}, {200, 210, 222, 100}, {200, 210, 222, 150}
	}
	draw_button(jump_button(w, h), "jump", fill, edge, ink)
}

// One line under the hand icon about the vessel the player is looking at or
// holding: what is in it and how full it is. The text is built in a buffer on
// the stack, so nothing is allocated each frame.
draw_contents :: proc(w, h: f32, pr: ^carry.Prop) {
	buf: [96]u8
	n := 0
	put :: proc(buf: []u8, n: ^int, text: string) {
		for c in transmute([]u8)text {
			if n^ < len(buf) - 1 {
				buf[n^] = c
				n^ += 1
			}
		}
	}
	digits: [24]u8
	put(buf[:], &n, carry.compound_name(pr.compound))
	if pr.compound != 0 {
		put(buf[:], &n, "  ")
		put(buf[:], &n, strconv.write_int(digits[:], i64(pr.ml + 0.5), 10))
		put(buf[:], &n, " / ")
		put(buf[:], &n, strconv.write_int(digits[:], i64(carry.capacity_ml(pr.kind) + 0.5), 10))
		put(buf[:], &n, " ml")
	}
	text := cstring(raw_data(buf[:]))
	font := i32(max(f32(16), h * 0.032))
	x := i32(w * 0.5) - rl.MeasureText(text, font) / 2
	y := i32(h * 0.5) + i32(max(f32(30), h * 0.075)) + 24
	rl.DrawText(text, x + 1, y + 2, font, {0, 0, 0, 220})
	rl.DrawText(text, x, y, font, rl.RAYWHITE)
}

// Draws a hand icon with its top left corner at (x, y) and `size` pixels
// across: a dark outline first, then the fill, so it reads on any background.
draw_icon :: proc(boxes: []Icon_Box, x, y, size: f32, fill: rl.Color) {
	outline := f32(2)
	for b in boxes {
		rect := rl.Rectangle{x + b.x * size - outline, y + b.y * size - outline, b.w * size + 2 * outline, b.h * size + 2 * outline}
		rl.DrawRectangleRounded(rect, 0.45, 6, {10, 18, 26, 255})
	}
	for b in boxes {
		rect := rl.Rectangle{x + b.x * size, y + b.y * size, b.w * size, b.h * size}
		c := rl.Color{u8(f32(fill.r) * b.shade), u8(f32(fill.g) * b.shade), u8(f32(fill.b) * b.shade), 255}
		rl.DrawRectangleRounded(rect, 0.45, 6, c)
	}
}

// The crosshair dot at the middle of the screen with a hand under it: an open
// hand in white while nothing is in reach, in teal when something is, and a
// closed fist while holding.
draw_crosshair :: proc(w, h: f32, state: carry.State) {
	cx, cy := i32(w * 0.5), i32(h * 0.5)
	radius := max(f32(3), h * 0.006)
	dot := rl.Color{255, 255, 255, 235}
	hand := rl.Color{226, 232, 238, 255}
	switch state {
	case .Idle:
	case .Reaching:
		radius *= 1.6
		dot, hand = {60, 230, 215, 255}, {60, 230, 215, 255}
	case .Holding:
		hand = rl.RAYWHITE
	}
	rl.DrawCircle(cx, cy, radius + 1.5, {10, 18, 26, 170})
	rl.DrawCircle(cx, cy, radius, dot)

	size := max(f32(30), h * 0.075)
	x := f32(cx) - size * 0.5
	y := f32(cy) + radius + 8
	if state == .Holding {
		closed := ICON_CLOSED
		draw_icon(closed[:], x, y, size, hand)
	} else {
		open := ICON_OPEN
		draw_icon(open[:], x, y, size, hand)
	}
}

draw_bench_button :: proc(w, h: f32) {
	draw_button(bench_button(w, h), "sim test", {10, 18, 28, 190}, {230, 236, 242, 200}, rl.RAYWHITE)
}
