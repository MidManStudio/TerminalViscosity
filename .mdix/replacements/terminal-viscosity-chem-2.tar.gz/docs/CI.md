# CI and tooling

## Overview

Two GitHub Actions workflows and four scripts. The workflow files are not part of the replacements archive. The token that runs the replacements workflow cannot create files under `.github/workflows/`, so those two files are added to the repository by hand.

## Workflows

- `.github/workflows/ci.yml` runs on pushes to `main`, on pull requests, and on demand.
  - `rust` builds and tests the workspace on Rust 1.75 and on stable. On stable it also checks formatting, runs clippy with warnings denied, and builds the docs with warnings denied.
  - `determinism` builds `tv_server`, runs the self-test twice with seed 1 in separate processes and requires identical output, then requires that seed 2 gives different output.
  - `docs` runs `scripts/check_headers.py`.
  - `chemistry-pages` installs the DixScript compiler for Python, runs `scripts/check_chem.py` on `data/chem`, and runs `scripts/gen_chem.py --check`, which fails if `client/src/chemistry/pages_data.odin` is not what the pages make.
  - `odin` installs a pinned Odin release (`ODIN_TAG` at the top of the file), type-checks the client, runs the soft-body, balloon, lab, carry, chemistry, effects, arena, touch, chemistry page engine, character, and liquid simulation tests, runs the store tests twice (against a stand-in DixScript library built from `client/src/store/testdata/fake_mdix_ffi.c`, then against DixScript's real Linux library, checked by commit and checksum), validates every shader file, the glass and liquid shader included, with glslang, builds the client and runs its self-test, then renders headless screenshots of the lab room, of the balloon held by its tip, and of the coliseum under a virtual display and keeps them as the `lab-screenshot` artifact.
- `.github/workflows/bench.yml` runs on demand and on pushes to `main` that touch code or benchmark files. It runs the Criterion benchmarks and the Odin benchmark, merges them with `scripts/bench_summary.py`, compares against `benches/baseline.json` with `scripts/bench_compare.py`, and uploads `bench-results`. Comparison only reports by default. The `fail_pct` input turns a regression above that percentage into a failure.

- `.github/workflows/android.yml` runs on demand only. It sets up Java 17, the Android SDK with build-tools 34.0.0, NDK r26d, Rust with the `armv7-linux-androideabi` target, and Odin, runs `scripts/build_android.sh`, and uploads a signed debug APK named `terminal-viscosity-armv7-debug.apk`. The setup mirrors the working midnote Android workflow.

Not covered yet: the browser (WebAssembly) build, any server networking, and chemistry adapters. See `docs/OPEN_DECISIONS.md`.

## Modules

### `check_headers.py`
**What it does:** Enforces the documentation guidelines. Every `.rs`, `.odin`, `.h`, `.fs`, `.py`, `.sh`, and `.toml` file must open with the NOTICE header, the doc file it names must exist, that doc must have a section for the file, crate docs must end with Fixes and Problems, and docs must avoid em dashes and filler words.

**Decisions:**
- `docs/references/` and `.mdix/` are skipped, since those hold copied material.
- The doc root for a file is the nearest ancestor directory that has a `docs/` folder.
- Run it with `python3 scripts/check_headers.py` from the repository root.

### `bench_summary.py`
**What it does:** Reads Criterion output and the Odin benchmark text file, writes `bench_results.json`, and prints a markdown table, which it also appends to the job summary when running in Actions.

**Decisions:** Results are keyed `rust/<criterion id>` and `odin/<name>`, and compared by median.

### `bench_compare.py`
**What it does:** Compares two result files and flags changes beyond `--warn-pct` (25 by default). With `--fail-pct` above zero it exits non-zero on a larger regression.

**Decisions:** Report-only by default, because hosted runners are noisy. A missing baseline is not an error.

### `build_client.sh`
**What it does:** Builds the Rust static library, builds the Odin client into `build/`, copies the shaders next to it, and optionally runs `--selftest`.

### `check_chem.py`
**What it does:** Checks the compound pages in `data/chem` against the rules of `docs/REACTIONS.md`. Each page is compiled by the real DixScript compiler, from the `midmanstudio-mdix` package for Python, read back, and checked one page at a time and then all together: who the compound is and how it looks, its purity bands, its reactions, its electrolysis, the levels (at most two), and that no two liquids share a seed or look alike. The list of what it checks is in `docs/REACTIONS.md`. It prints a line for every problem and exits 1 if there is any. With no `data/chem` folder it says so and exits 0, so it can be run before there are pages.

**Decisions:**
- It uses the real compiler and not a parser of its own, so a page that compiles for the game compiles for the checker. The compiler writes its log below Python's reach, so the script silences the two file descriptors while it loads.
- A page that fails to compile is reported and left out of the rest of the checks, so one bad page does not hide the others' problems.
- The enum numbers are read from `core/enums.mdix`, so the vocabulary has one home.
- The `chemistry-pages` job of CI runs it. By hand: `pip install midmanstudio-mdix` and `python3 scripts/check_chem.py data/chem`.
- `index.mdix` is not a page. It lists the ids of the pages in order, and each compound's number is its place in the list, counted from 1, so a new compound goes at the end and the numbers that saves and the network carry never move. The checker reports a page that is not in the list, an id in the list with no page, and an id listed twice.

### `gen_chem.py`
**What it does:** Writes `client/src/chemistry/pages_data.odin` from the compound pages in `data/chem`. It runs `check_chem.py` first and stops if the pages do not pass, compiles the pages with the real DixScript compiler, numbers the compounds by the order of `index.mdix`, and writes the compounds, purity bands, behaviours, reaction inputs and outputs, reactions and electrolyses as constant tables, sorted so that the same pages always make the same file. With `--check` it writes nothing and exits 1 if the file on disk is not what the pages make. With no `data/chem` folder it says so and exits 0.

**Decisions:**
- The game does not read the pages while it runs. The client's binding of the DixScript library reads whole numbers and text only, takes no list or decimal, and cannot follow the imports the pages use, so reading them there would first need a larger binding that nothing can try outside a phone. A generated file is checked into the repo, compiled with the game, the same on every platform, and the server can later get a copy made from the same pages by the same script.
- The pages stay the single source. `--check` in CI is what stops a page from being edited without the tables being made again.
- Reactions are written in the order of their page, and inside a page by id, so that the tie rule of the engine (the one listed first) does not depend on the order the compiler happens to return them in.
- At most 64 reactions are allowed, one bit each in the `u64` that remembers which have run.
- The script needs Python and the `midmanstudio-mdix` package. It has not been tried in Termux.

### `check_android_abi.py`
**What it does:** Reads the undefined symbols of the Odin object files, matches them against the prototypes in `raylib.h` and `rlgl.h`, and fails if any raylib function that Odin calls returns a struct made only of floats (`Vector2`, `Vector3`, `Vector4`, `Quaternion`, `Rectangle`, `Matrix`, and similar).

**Decisions:**
- Odin's 32-bit ARM backend returns those in registers and the NDK returns them through a hidden pointer, so a direct call crashes. Such calls must go through a C wrapper in `android/entry.c`.
- Integer-only structs such as `Color` and `Shader` are lowered the same way on both sides and are allowed.
- It was tested against the objects from before the fix, where it flags `GetMousePosition`, and against the fixed objects, where it passes.
- `rlgl.h` is read from the directory of `raylib.h`. Five rlgl functions return a `Matrix`, and the guard now stops a call to any of them. It covers return values only. Struct arguments were compared by hand for the 3D calls, see `client/docs/client.md`, section `android_entry.odin` under Fixes and Problems.

### `build_android.sh`
**What it does:** Builds the Android debug APK in five stages that can be run separately: `raylib`, `rust`, `odin`, `link`, `package`. Output goes to `build/android/`.

**Decisions:**
- Odin only compiles. The final link is done with the NDK's clang, because Odin's own Android link modes did not fit raylib's startup, see `android/docs/android.md`.
- The link flags follow raylib's own Android template. `-Wl,--wrap=fopen` is mandatory, because raylib's Android backend reads assets through a wrapped `fopen`. `-Wl,--no-undefined` makes a missing symbol fail in CI instead of when the app starts.
- Packaging follows raylib's own Android recipe: `aapt package`, then `aapt add` for the library, `zipalign`, then `apksigner` with a throwaway debug key. No secrets are involved.
- The Odin objects are built with `-microarch:cortex-a7`, because Odin's 32-bit ARM default is an ARMv6 CPU. After the Odin stage, `scripts/check_android_abi.py` runs.
- Settings come from environment variables (`TV_ANDROID_API`, `TV_ANDROID_TARGET_SDK`, `TV_ANDROID_BUILD_TOOLS`, `TV_ANDROID_PLATFORM`, `TV_RAYLIB_TAG`, `TV_OPT`, `TV_MDIX_COMMIT`, `TV_MDIX_SHA256`).
- `TV_OPT` is the Odin optimization level and defaults to `minimal`, the level known to run on the phone. `size` also compiles for 32-bit ARM and makes the balloon physics about five times faster on the desktop, but it has not been tried on a device. With `size`, Odin writes one object file instead of one per package, which the later stages handle.
- The `mdix` stage fetches `libmdix_ffi.so` for armeabi-v7a, the library the game's local database runs on. DixScript's own CI builds and commits it for its Unity package, so no Rust is compiled here. The file is downloaded by commit, checked against a pinned SHA-256, and checked to be a 32-bit ARM library that exports the entry points the game looks up. It needs only `libdl`, `libm`, and `libc`, which every Android has. The `package` stage then adds it next to `libmain.so`. To move to a newer DixScript, change `TV_MDIX_COMMIT` and `TV_MDIX_SHA256` together, here and in the matching step of `ci.yml`.

## Fixes and Problems

### `check_headers.py`
- None recorded yet.

### `bench_summary.py`
- None recorded yet.

### `bench_compare.py`
- None recorded yet.

### `build_client.sh`
- The shaders were first read from the working directory. The script now copies them next to the executable, and the client resolves them from there.

### `build_android.sh`
- First CI run: the `raylib`, `rust`, and `odin` stages passed on the real NDK (raylib 6.0 built for armv7, `tv_ffi` built for `armv7-linux-androideabi`, 45 Odin objects). The `link` stage failed with `undefined symbol: __real_fopen`, because the link line lacked `-Wl,--wrap=fopen`, which raylib's source says every final link must pass. Added, together with the other flags from raylib's Android template.
- raylib's Makefile redefines `__ANDROID_API__` on the command line, which prints a harmless macro-redefinition warning for every file.
- The `package` stage was run locally with Ubuntu's `aapt`, `zipalign`, and `apksigner`. It has not yet run in CI.
- The Odin stage with `TV_OPT=size` was run locally against a placeholder NDK: it produces one object file and passes the ABI guard. It has not been linked or run.
- The first version of the `mdix` stage said a valid library was "not 32-bit". The script runs with `pipefail`, and `grep -q` stops reading as soon as it matches, so the tool feeding it died of a broken pipe and the check counted as failed. The stage now captures each tool's output before searching it.
- The `mdix` stage was run locally against a stand-in NDK: it downloaded the real file, matched the checksum, rejected a wrong checksum, and found the entry points. The `aapt add` line that puts two libraries in the APK was tried on a dummy APK, and `zipalign` accepted the result. It has not run in CI, and the library has not been loaded on a phone.

### `check_android_abi.py`
- Written after the first installed build crashed on launch. See `client/docs/client.md`, section `android_entry.odin`.
- Extended to `rlgl.h` when the client started calling rlgl functions for the 3D lab. It now checks 50 functions on the real client objects.

### `check_chem.py`
- It was run on the first 17 pages and found real mistakes in them: four pairs of liquids with colours too close together, and a melting point for carbon dioxide that was above its boiling point, because it sublimes.
- Its checks were tested by 28 deliberate breakages of the pages, each in a copy, one at a time: a wrong level, a level 3, equal and close colours, equal seeds, a gap in the bands, a missing page, a bad `first`, a reaction on the wrong page, two reactions that can both match, a failure below the window, electrolysis of a band that does not exist, gear that is not in the list, a meter above 1, a catalyst that is an input, overlapping behaviors, a reused id, a product that nothing makes, a page that does not compile, and more. Each was reported, and for the right reason. A first run counted any non-zero exit as a catch, which would have counted a crash, so the test now needs a reported problem and no traceback.
- One breakage to test a reused id broke the page it was made in and was not testing what it said. It was replaced by one that compiles.
- The index check was tried on three breakages in a copy: an id listed twice, a missing `index.mdix` and a page left out of it. Each was reported. It has not been run in CI yet: the job is new.

### `gen_chem.py`
- It was run on the 17 pages, made the file, and `--check` agreed with it. The tables it makes are read by 27 tests of the `chemistry` package that pin the numbers of the pages, so the script and the tests check each other: a wrong sort or a lost field shows as a failing test.
- Not run in CI yet: the job is new, and the pages are not in the repo until the owner adds them.
- Not tried in Termux, where the Python package may not install.

